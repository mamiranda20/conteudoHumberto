﻿Imports System.Data.SqlClient

Public Class Form3

    Dim conexao As New SqlConnection("Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=cad_livraria;Integrated Security=True")

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            configurarFormulario()
            carregarClientes()
            carregarLivros()
            limparCamposItem()
            limparVenda()
        Catch ex As Exception
            MessageBox.Show("Erro ao abrir o formulário: " & ex.Message)
        End Try
    End Sub

    Private Sub configurarFormulario()
        txt_id_venda.ReadOnly = True
        txt_isbn.ReadOnly = True
        txt_estoque.ReadOnly = True
        txt_preco_unitario.ReadOnly = True
        txt_subtotal.ReadOnly = True
        txt_total_venda.ReadOnly = True

        cmb_cliente.DropDownStyle = ComboBoxStyle.DropDownList
        cmb_livro.DropDownStyle = ComboBoxStyle.DropDownList

        dtp_data_venda.Format = DateTimePickerFormat.Custom
        dtp_data_venda.CustomFormat = "dd/MM/yyyy"

        dgv_itens_venda.Rows.Clear()
    End Sub

    Private Sub carregarClientes()
        Try
            Dim sql As String = "SELECT id_cliente, nome FROM tb_clientes ORDER BY nome"

            Dim cmd As New SqlCommand(sql, conexao)
            Dim da As New SqlDataAdapter(cmd)
            Dim dt As New DataTable()

            da.Fill(dt)

            cmb_cliente.DataSource = dt
            cmb_cliente.DisplayMember = "nome"
            cmb_cliente.ValueMember = "id_cliente"
            cmb_cliente.SelectedIndex = -1

        Catch ex As Exception
            MessageBox.Show("Erro ao carregar clientes: " & ex.Message)
        End Try
    End Sub

    Private Sub carregarLivros()
        Try
            Dim sql As String = "SELECT isbn, titulo FROM tb_livros ORDER BY titulo"

            Dim cmd As New SqlCommand(sql, conexao)
            Dim da As New SqlDataAdapter(cmd)
            Dim dt As New DataTable()

            da.Fill(dt)

            cmb_livro.DataSource = dt
            cmb_livro.DisplayMember = "titulo"
            cmb_livro.ValueMember = "isbn"
            cmb_livro.SelectedIndex = -1

        Catch ex As Exception
            MessageBox.Show("Erro ao carregar livros: " & ex.Message)
        End Try
    End Sub

    Private Sub limparCamposItem()
        txt_isbn.Text = ""
        txt_estoque.Text = ""
        txt_preco_unitario.Text = ""
        txt_quantidade.Text = ""
        txt_subtotal.Text = ""

        If cmb_livro.Items.Count > 0 Then
            cmb_livro.SelectedIndex = -1
        End If
    End Sub

    Private Sub limparVenda()
        txt_id_venda.Text = ""
        txt_total_venda.Text = "0,00"
        dtp_data_venda.Value = Date.Now

        If cmb_cliente.Items.Count > 0 Then
            cmb_cliente.SelectedIndex = -1
        End If

        dgv_itens_venda.Rows.Clear()
        limparCamposItem()
    End Sub

    Private Sub cmb_livro_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb_livro.SelectedIndexChanged
        Try
            If cmb_livro.SelectedIndex = -1 OrElse cmb_livro.SelectedValue Is Nothing Then Exit Sub

            Dim isbnSelecionado As String = cmb_livro.SelectedValue.ToString()

            Dim sql As String = "SELECT isbn, quantidade, preco_venda FROM tb_livros WHERE isbn = @isbn"
            Dim cmd As New SqlCommand(sql, conexao)
            cmd.Parameters.AddWithValue("@isbn", isbnSelecionado)

            conexao.Open()

            Dim dr As SqlDataReader = cmd.ExecuteReader()

            If dr.Read() Then
                txt_isbn.Text = dr("isbn").ToString()
                txt_estoque.Text = dr("quantidade").ToString()
                txt_preco_unitario.Text = Convert.ToDecimal(dr("preco_venda")).ToString("N2")
            End If

            dr.Close()
            conexao.Close()

            calcularSubtotal()

        Catch ex As Exception
            If conexao.State = ConnectionState.Open Then
                conexao.Close()
            End If
            MessageBox.Show("Erro ao buscar dados do livro: " & ex.Message)
        End Try
    End Sub

    Private Sub txt_quantidade_TextChanged(sender As Object, e As EventArgs) Handles txt_quantidade.TextChanged
        calcularSubtotal()
    End Sub

    Private Sub calcularSubtotal()
        Try
            If txt_quantidade.Text.Trim() = "" OrElse txt_preco_unitario.Text.Trim() = "" Then
                txt_subtotal.Text = ""
                Exit Sub
            End If

            Dim quantidade As Integer
            Dim preco As Decimal

            If Integer.TryParse(txt_quantidade.Text, quantidade) = False Then
                txt_subtotal.Text = ""
                Exit Sub
            End If

            If Decimal.TryParse(txt_preco_unitario.Text, preco) = False Then
                txt_subtotal.Text = ""
                Exit Sub
            End If

            Dim subtotal As Decimal = quantidade * preco
            txt_subtotal.Text = subtotal.ToString("N2")

        Catch ex As Exception
            txt_subtotal.Text = ""
        End Try
    End Sub

    Private Sub btn_adicionar_item_Click(sender As Object, e As EventArgs) Handles btn_adicionar_item.Click
        Try
            If cmb_livro.SelectedIndex = -1 Then
                MessageBox.Show("Selecione um livro.")
                Exit Sub
            End If

            If txt_quantidade.Text.Trim() = "" Then
                MessageBox.Show("Digite a quantidade.")
                txt_quantidade.Focus()
                Exit Sub
            End If

            Dim quantidade As Integer
            Dim estoque As Integer
            Dim preco As Decimal
            Dim subtotal As Decimal

            If Integer.TryParse(txt_quantidade.Text, quantidade) = False OrElse quantidade <= 0 Then
                MessageBox.Show("Digite uma quantidade válida.")
                txt_quantidade.Focus()
                Exit Sub
            End If

            If Integer.TryParse(txt_estoque.Text, estoque) = False Then
                MessageBox.Show("Estoque inválido.")
                Exit Sub
            End If

            If quantidade > estoque Then
                MessageBox.Show("Quantidade maior que o estoque disponível.")
                txt_quantidade.Focus()
                Exit Sub
            End If

            If Decimal.TryParse(txt_preco_unitario.Text, preco) = False Then
                MessageBox.Show("Preço inválido.")
                Exit Sub
            End If

            If Decimal.TryParse(txt_subtotal.Text, subtotal) = False Then
                MessageBox.Show("Subtotal inválido.")
                Exit Sub
            End If

            ' Verifica se o livro já foi adicionado
            For Each linha As DataGridViewRow In dgv_itens_venda.Rows
                If Not linha.IsNewRow Then
                    If linha.Cells("col_isbn").Value.ToString() = txt_isbn.Text Then
                        MessageBox.Show("Este livro já foi adicionado na venda.")
                        Exit Sub
                    End If
                End If
            Next

            dgv_itens_venda.Rows.Add(
                txt_isbn.Text,
                cmb_livro.Text,
                txt_estoque.Text,
                preco.ToString("N2"),
                quantidade,
                subtotal.ToString("N2"),
                "EXCLUIR"
            )

            calcularTotalVenda()
            limparCamposItem()

        Catch ex As Exception
            MessageBox.Show("Erro ao adicionar item: " & ex.Message)
        End Try
    End Sub

    Private Sub calcularTotalVenda()
        Dim total As Decimal = 0

        For Each linha As DataGridViewRow In dgv_itens_venda.Rows
            If Not linha.IsNewRow Then
                total += Convert.ToDecimal(linha.Cells("col_subtotal").Value)
            End If
        Next

        txt_total_venda.Text = total.ToString("N2")
    End Sub

    Private Sub dgv_itens_venda_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_itens_venda.CellContentClick
        Try
            If e.RowIndex < 0 Then Exit Sub

            If dgv_itens_venda.Columns(e.ColumnIndex).Name = "col_excluir" Then
                dgv_itens_venda.Rows.RemoveAt(e.RowIndex)
                calcularTotalVenda()
            End If

        Catch ex As Exception
            MessageBox.Show("Erro ao excluir item: " & ex.Message)
        End Try
    End Sub

    Private Sub btn_salvar_venda_Click(sender As Object, e As EventArgs) Handles btn_salvar_venda.Click
        Try
            ' Validações básicas
            If cmb_cliente.SelectedIndex = -1 Then
                MessageBox.Show("Selecione um cliente.")
                Exit Sub
            End If

            If dgv_itens_venda.Rows.Count = 0 Then
                MessageBox.Show("Adicione pelo menos um item na venda.")
                Exit Sub
            End If

            If txt_total_venda.Text.Trim() = "" OrElse txt_total_venda.Text = "0,00" Then
                MessageBox.Show("Total da venda inválido.")
                Exit Sub
            End If

            Dim idCliente As Integer = Convert.ToInt32(cmb_cliente.SelectedValue)
            Dim dataVenda As Date = dtp_data_venda.Value
            Dim totalVenda As Decimal = Convert.ToDecimal(txt_total_venda.Text)

            conexao.Open()

            Dim transacao As SqlTransaction = conexao.BeginTransaction()

            Try
                ' 1) Salva na tb_vendas
                Dim sqlVenda As String = "INSERT INTO tb_vendas (id_cliente, data_venda, total_venda) " &
                                     "VALUES (@id_cliente, @data_venda, @total_venda); " &
                                     "SELECT SCOPE_IDENTITY();"

                Dim cmdVenda As New SqlCommand(sqlVenda, conexao, transacao)
                cmdVenda.Parameters.AddWithValue("@id_cliente", idCliente)
                cmdVenda.Parameters.AddWithValue("@data_venda", dataVenda)
                cmdVenda.Parameters.AddWithValue("@total_venda", totalVenda)

                Dim idVendaGerado As Integer = Convert.ToInt32(cmdVenda.ExecuteScalar())

                ' Mostra o id da venda na tela
                txt_id_venda.Text = idVendaGerado.ToString()

                ' 2) Salva os itens da venda
                For Each linha As DataGridViewRow In dgv_itens_venda.Rows
                    If Not linha.IsNewRow Then

                        Dim isbn As String = linha.Cells("col_isbn").Value.ToString()
                        Dim quantidade As Integer = Convert.ToInt32(linha.Cells("col_quantidade").Value)
                        Dim precoUnitario As Decimal = Convert.ToDecimal(linha.Cells("col_preco_unitario").Value)
                        Dim subtotal As Decimal = Convert.ToDecimal(linha.Cells("col_subtotal").Value)

                        Dim sqlItem As String = "INSERT INTO tb_itens_venda (id_venda, isbn, quantidade, preco_unitario, subtotal) " &
                                            "VALUES (@id_venda, @isbn, @quantidade, @preco_unitario, @subtotal)"

                        Dim cmdItem As New SqlCommand(sqlItem, conexao, transacao)
                        cmdItem.Parameters.AddWithValue("@id_venda", idVendaGerado)
                        cmdItem.Parameters.AddWithValue("@isbn", isbn)
                        cmdItem.Parameters.AddWithValue("@quantidade", quantidade)
                        cmdItem.Parameters.AddWithValue("@preco_unitario", precoUnitario)
                        cmdItem.Parameters.AddWithValue("@subtotal", subtotal)

                        cmdItem.ExecuteNonQuery()

                        ' 3) Atualiza o estoque em tb_livros
                        Dim sqlEstoque As String = "UPDATE tb_livros " &
                                               "SET quantidade = quantidade - @quantidade " &
                                               "WHERE isbn = @isbn"

                        Dim cmdEstoque As New SqlCommand(sqlEstoque, conexao, transacao)
                        cmdEstoque.Parameters.AddWithValue("@quantidade", quantidade)
                        cmdEstoque.Parameters.AddWithValue("@isbn", isbn)

                        cmdEstoque.ExecuteNonQuery()
                    End If
                Next

                ' 4) Confirma tudo
                transacao.Commit()

                MessageBox.Show("Venda salva com sucesso e estoque atualizado!")

                limparVendaCompleta()

            Catch ex As Exception
                transacao.Rollback()
                MessageBox.Show("Erro ao salvar venda: " & ex.Message)
            End Try

            conexao.Close()

        Catch ex As Exception
            If conexao.State = ConnectionState.Open Then
                conexao.Close()
            End If

            MessageBox.Show("Erro geral ao salvar: " & ex.Message)
        End Try
    End Sub

    Private Sub limparVendaCompleta()
        txt_id_venda.Text = ""
        txt_total_venda.Text = "0,00"
        dtp_data_venda.Value = Date.Now

        If cmb_cliente.Items.Count > 0 Then
            cmb_cliente.SelectedIndex = -1
        End If

        dgv_itens_venda.Rows.Clear()

        txt_isbn.Text = ""
        txt_estoque.Text = ""
        txt_preco_unitario.Text = ""
        txt_quantidade.Text = ""
        txt_subtotal.Text = ""

        If cmb_livro.Items.Count > 0 Then
            cmb_livro.SelectedIndex = -1
        End If
    End Sub

End Class