﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.txt_cpf = New System.Windows.Forms.TextBox()
        Me.txt_email = New System.Windows.Forms.MaskedTextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txt_telefone = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.btn_gravar_clientes = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.txt_buscar_cliente = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripLabel2 = New System.Windows.Forms.ToolStripLabel()
        Me.cmb_campo_cliente = New System.Windows.Forms.ToolStripComboBox()
        Me.img_foto_clientes = New System.Windows.Forms.PictureBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_nome = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txt_id_cliente = New System.Windows.Forms.MaskedTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dgv_dados_clientes = New System.Windows.Forms.DataGridView()
        Me.col_id_cliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_nome = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_cpf = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_telefone = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_email = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_editar = New System.Windows.Forms.DataGridViewImageColumn()
        Me.col_excluir = New System.Windows.Forms.DataGridViewImageColumn()
        Me.ToolStrip1.SuspendLayout()
        CType(Me.img_foto_clientes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_dados_clientes, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txt_cpf
        '
        Me.txt_cpf.AccessibleRole = System.Windows.Forms.AccessibleRole.Window
        Me.txt_cpf.BackColor = System.Drawing.Color.BurlyWood
        Me.txt_cpf.Location = New System.Drawing.Point(12, 159)
        Me.txt_cpf.Name = "txt_cpf"
        Me.txt_cpf.Size = New System.Drawing.Size(301, 20)
        Me.txt_cpf.TabIndex = 37
        '
        'txt_email
        '
        Me.txt_email.BackColor = System.Drawing.Color.BurlyWood
        Me.txt_email.Location = New System.Drawing.Point(330, 159)
        Me.txt_email.Name = "txt_email"
        Me.txt_email.Size = New System.Drawing.Size(244, 20)
        Me.txt_email.TabIndex = 36
        Me.txt_email.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(327, 143)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(48, 13)
        Me.Label8.TabIndex = 35
        Me.Label8.Text = "E-MAIL"
        '
        'txt_telefone
        '
        Me.txt_telefone.BackColor = System.Drawing.Color.BurlyWood
        Me.txt_telefone.Location = New System.Drawing.Point(330, 110)
        Me.txt_telefone.Name = "txt_telefone"
        Me.txt_telefone.Size = New System.Drawing.Size(244, 20)
        Me.txt_telefone.TabIndex = 32
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(327, 93)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(71, 13)
        Me.Label6.TabIndex = 31
        Me.Label6.Text = "TELEFONE"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.BackColor = System.Drawing.Color.RosyBrown
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btn_gravar_clientes, Me.ToolStripLabel1, Me.txt_buscar_cliente, Me.ToolStripLabel2, Me.cmb_campo_cliente})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(800, 27)
        Me.ToolStrip1.TabIndex = 30
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'btn_gravar_clientes
        '
        Me.btn_gravar_clientes.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btn_gravar_clientes.Image = CType(resources.GetObject("btn_gravar_clientes.Image"), System.Drawing.Image)
        Me.btn_gravar_clientes.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btn_gravar_clientes.Name = "btn_gravar_clientes"
        Me.btn_gravar_clientes.Size = New System.Drawing.Size(24, 24)
        Me.btn_gravar_clientes.Text = "ToolStripButton1"
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(194, 24)
        Me.ToolStripLabel1.Text = "Digite um parâmetro de pesquisa:"
        '
        'txt_buscar_cliente
        '
        Me.txt_buscar_cliente.BackColor = System.Drawing.Color.BurlyWood
        Me.txt_buscar_cliente.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt_buscar_cliente.Name = "txt_buscar_cliente"
        Me.txt_buscar_cliente.Size = New System.Drawing.Size(100, 27)
        '
        'ToolStripLabel2
        '
        Me.ToolStripLabel2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel2.Name = "ToolStripLabel2"
        Me.ToolStripLabel2.Size = New System.Drawing.Size(111, 24)
        Me.ToolStripLabel2.Text = "Selecione o campo"
        '
        'cmb_campo_cliente
        '
        Me.cmb_campo_cliente.BackColor = System.Drawing.Color.BurlyWood
        Me.cmb_campo_cliente.Name = "cmb_campo_cliente"
        Me.cmb_campo_cliente.Size = New System.Drawing.Size(121, 27)
        '
        'img_foto_clientes
        '
        Me.img_foto_clientes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.img_foto_clientes.Image = CType(resources.GetObject("img_foto_clientes.Image"), System.Drawing.Image)
        Me.img_foto_clientes.Location = New System.Drawing.Point(617, 60)
        Me.img_foto_clientes.Name = "img_foto_clientes"
        Me.img_foto_clientes.Size = New System.Drawing.Size(160, 155)
        Me.img_foto_clientes.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.img_foto_clientes.TabIndex = 26
        Me.img_foto_clientes.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(9, 143)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(30, 13)
        Me.Label3.TabIndex = 25
        Me.Label3.Text = "CPF"
        '
        'txt_nome
        '
        Me.txt_nome.AccessibleRole = System.Windows.Forms.AccessibleRole.Window
        Me.txt_nome.BackColor = System.Drawing.Color.BurlyWood
        Me.txt_nome.Location = New System.Drawing.Point(12, 110)
        Me.txt_nome.Name = "txt_nome"
        Me.txt_nome.Size = New System.Drawing.Size(301, 20)
        Me.txt_nome.TabIndex = 24
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(9, 93)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(43, 13)
        Me.Label2.TabIndex = 23
        Me.Label2.Text = "NOME"
        '
        'txt_id_cliente
        '
        Me.txt_id_cliente.BackColor = System.Drawing.Color.BurlyWood
        Me.txt_id_cliente.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_id_cliente.Location = New System.Drawing.Point(12, 61)
        Me.txt_id_cliente.Name = "txt_id_cliente"
        Me.txt_id_cliente.Size = New System.Drawing.Size(100, 13)
        Me.txt_id_cliente.TabIndex = 22
        Me.txt_id_cliente.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(9, 44)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 13)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "ID CLIENTE"
        '
        'dgv_dados_clientes
        '
        Me.dgv_dados_clientes.AllowUserToAddRows = False
        Me.dgv_dados_clientes.AllowUserToDeleteRows = False
        Me.dgv_dados_clientes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgv_dados_clientes.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgv_dados_clientes.BackgroundColor = System.Drawing.Color.Bisque
        Me.dgv_dados_clientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_dados_clientes.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.col_id_cliente, Me.col_nome, Me.col_cpf, Me.col_telefone, Me.col_email, Me.col_editar, Me.col_excluir})
        Me.dgv_dados_clientes.Location = New System.Drawing.Point(0, 236)
        Me.dgv_dados_clientes.Name = "dgv_dados_clientes"
        Me.dgv_dados_clientes.ReadOnly = True
        Me.dgv_dados_clientes.RowHeadersWidth = 51
        Me.dgv_dados_clientes.Size = New System.Drawing.Size(800, 187)
        Me.dgv_dados_clientes.TabIndex = 38
        '
        'col_id_cliente
        '
        Me.col_id_cliente.DataPropertyName = "id_cliente"
        Me.col_id_cliente.HeaderText = "ID"
        Me.col_id_cliente.MinimumWidth = 6
        Me.col_id_cliente.Name = "col_id_cliente"
        Me.col_id_cliente.ReadOnly = True
        Me.col_id_cliente.Width = 43
        '
        'col_nome
        '
        Me.col_nome.DataPropertyName = "nome"
        Me.col_nome.HeaderText = "NOME"
        Me.col_nome.MinimumWidth = 6
        Me.col_nome.Name = "col_nome"
        Me.col_nome.ReadOnly = True
        Me.col_nome.Width = 64
        '
        'col_cpf
        '
        Me.col_cpf.DataPropertyName = "cpf"
        Me.col_cpf.HeaderText = "CPF"
        Me.col_cpf.Name = "col_cpf"
        Me.col_cpf.ReadOnly = True
        Me.col_cpf.Width = 52
        '
        'col_telefone
        '
        Me.col_telefone.DataPropertyName = "telefone"
        Me.col_telefone.HeaderText = "TELEFONE"
        Me.col_telefone.Name = "col_telefone"
        Me.col_telefone.ReadOnly = True
        Me.col_telefone.Width = 88
        '
        'col_email
        '
        Me.col_email.DataPropertyName = "email"
        Me.col_email.HeaderText = "E-MAIL"
        Me.col_email.Name = "col_email"
        Me.col_email.ReadOnly = True
        Me.col_email.Width = 67
        '
        'col_editar
        '
        Me.col_editar.HeaderText = "EDITAR"
        Me.col_editar.Image = CType(resources.GetObject("col_editar.Image"), System.Drawing.Image)
        Me.col_editar.MinimumWidth = 6
        Me.col_editar.Name = "col_editar"
        Me.col_editar.ReadOnly = True
        Me.col_editar.Width = 53
        '
        'col_excluir
        '
        Me.col_excluir.HeaderText = "EXCLUIR"
        Me.col_excluir.Image = CType(resources.GetObject("col_excluir.Image"), System.Drawing.Image)
        Me.col_excluir.MinimumWidth = 6
        Me.col_excluir.Name = "col_excluir"
        Me.col_excluir.ReadOnly = True
        Me.col_excluir.Width = 59
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.dgv_dados_clientes)
        Me.Controls.Add(Me.txt_cpf)
        Me.Controls.Add(Me.txt_email)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txt_telefone)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.img_foto_clientes)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txt_nome)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txt_id_cliente)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        CType(Me.img_foto_clientes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_dados_clientes, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txt_cpf As TextBox
    Friend WithEvents txt_email As MaskedTextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txt_telefone As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents btn_gravar_clientes As ToolStripButton
    Friend WithEvents ToolStripLabel1 As ToolStripLabel
    Friend WithEvents txt_buscar_cliente As ToolStripTextBox
    Friend WithEvents ToolStripLabel2 As ToolStripLabel
    Friend WithEvents cmb_campo_cliente As ToolStripComboBox
    Friend WithEvents img_foto_clientes As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txt_nome As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txt_id_cliente As MaskedTextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents dgv_dados_clientes As DataGridView
    Friend WithEvents col_id_cliente As DataGridViewTextBoxColumn
    Friend WithEvents col_nome As DataGridViewTextBoxColumn
    Friend WithEvents col_cpf As DataGridViewTextBoxColumn
    Friend WithEvents col_telefone As DataGridViewTextBoxColumn
    Friend WithEvents col_email As DataGridViewTextBoxColumn
    Friend WithEvents col_editar As DataGridViewImageColumn
    Friend WithEvents col_excluir As DataGridViewImageColumn
End Class
