﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form3))
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txt_isbn = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.btn_adicionar_item = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.txt_buscar_cliente = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripLabel2 = New System.Windows.Forms.ToolStripLabel()
        Me.cmb_campo_cliente = New System.Windows.Forms.ToolStripComboBox()
        Me.labelvenda = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txt_id_venda = New System.Windows.Forms.MaskedTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtp_data_venda = New System.Windows.Forms.DateTimePicker()
        Me.txt_quantidade = New System.Windows.Forms.MaskedTextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_preco_unitario = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txt_subtotal = New System.Windows.Forms.MaskedTextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.dgv_itens_venda = New System.Windows.Forms.DataGridView()
        Me.cmb_cliente = New System.Windows.Forms.ComboBox()
        Me.cmb_livro = New System.Windows.Forms.ComboBox()
        Me.txt_estoque = New System.Windows.Forms.MaskedTextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txt_total_venda = New System.Windows.Forms.MaskedTextBox()
        Me.btn_salvar_venda = New System.Windows.Forms.Button()
        Me.col_isbn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_livro = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_estoque = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_preco_unitario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_quantidade = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_subtotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_excluir = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.ToolStrip1.SuspendLayout()
        CType(Me.dgv_itens_venda, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(186, 95)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(44, 13)
        Me.Label8.TabIndex = 46
        Me.Label8.Text = "LIVRO"
        '
        'txt_isbn
        '
        Me.txt_isbn.BackColor = System.Drawing.Color.BurlyWood
        Me.txt_isbn.Location = New System.Drawing.Point(189, 62)
        Me.txt_isbn.Name = "txt_isbn"
        Me.txt_isbn.ReadOnly = True
        Me.txt_isbn.Size = New System.Drawing.Size(244, 20)
        Me.txt_isbn.TabIndex = 45
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(186, 45)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(36, 13)
        Me.Label6.TabIndex = 44
        Me.Label6.Text = "ISBN"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.BackColor = System.Drawing.Color.RosyBrown
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btn_adicionar_item, Me.ToolStripLabel1, Me.txt_buscar_cliente, Me.ToolStripLabel2, Me.cmb_campo_cliente})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(800, 27)
        Me.ToolStrip1.TabIndex = 43
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'btn_adicionar_item
        '
        Me.btn_adicionar_item.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btn_adicionar_item.Image = CType(resources.GetObject("btn_adicionar_item.Image"), System.Drawing.Image)
        Me.btn_adicionar_item.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btn_adicionar_item.Name = "btn_adicionar_item"
        Me.btn_adicionar_item.Size = New System.Drawing.Size(24, 24)
        Me.btn_adicionar_item.Text = "ToolStripButton1"
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(194, 24)
        Me.ToolStripLabel1.Text = "Digite um parâmetro de pesquisa:"
        '
        'txt_buscar_cliente
        '
        Me.txt_buscar_cliente.BackColor = System.Drawing.Color.BurlyWood
        Me.txt_buscar_cliente.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt_buscar_cliente.Name = "txt_buscar_cliente"
        Me.txt_buscar_cliente.Size = New System.Drawing.Size(100, 27)
        '
        'ToolStripLabel2
        '
        Me.ToolStripLabel2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel2.Name = "ToolStripLabel2"
        Me.ToolStripLabel2.Size = New System.Drawing.Size(111, 24)
        Me.ToolStripLabel2.Text = "Selecione o campo"
        '
        'cmb_campo_cliente
        '
        Me.cmb_campo_cliente.BackColor = System.Drawing.Color.BurlyWood
        Me.cmb_campo_cliente.Name = "cmb_campo_cliente"
        Me.cmb_campo_cliente.Size = New System.Drawing.Size(121, 27)
        '
        'labelvenda
        '
        Me.labelvenda.AutoSize = True
        Me.labelvenda.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labelvenda.Location = New System.Drawing.Point(9, 147)
        Me.labelvenda.Name = "labelvenda"
        Me.labelvenda.Size = New System.Drawing.Size(86, 13)
        Me.labelvenda.TabIndex = 42
        Me.labelvenda.Text = "DATA VENDA"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 94)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(59, 13)
        Me.Label2.TabIndex = 40
        Me.Label2.Text = "CLIENTE"
        '
        'txt_id_venda
        '
        Me.txt_id_venda.BackColor = System.Drawing.Color.BurlyWood
        Me.txt_id_venda.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txt_id_venda.Enabled = False
        Me.txt_id_venda.Location = New System.Drawing.Point(12, 62)
        Me.txt_id_venda.Name = "txt_id_venda"
        Me.txt_id_venda.Size = New System.Drawing.Size(100, 13)
        Me.txt_id_venda.TabIndex = 39
        Me.txt_id_venda.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(9, 45)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(66, 13)
        Me.Label1.TabIndex = 38
        Me.Label1.Text = "ID VENDA"
        '
        'dtp_data_venda
        '
        Me.dtp_data_venda.CustomFormat = "dd/MM/yyyy"
        Me.dtp_data_venda.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp_data_venda.Location = New System.Drawing.Point(12, 163)
        Me.dtp_data_venda.Name = "dtp_data_venda"
        Me.dtp_data_venda.Size = New System.Drawing.Size(130, 20)
        Me.dtp_data_venda.TabIndex = 48
        '
        'txt_quantidade
        '
        Me.txt_quantidade.BackColor = System.Drawing.Color.BurlyWood
        Me.txt_quantidade.Location = New System.Drawing.Point(482, 111)
        Me.txt_quantidade.Name = "txt_quantidade"
        Me.txt_quantidade.Size = New System.Drawing.Size(244, 20)
        Me.txt_quantidade.TabIndex = 52
        Me.txt_quantidade.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(479, 95)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 13)
        Me.Label3.TabIndex = 51
        Me.Label3.Text = "QUANTIDADE"
        '
        'txt_preco_unitario
        '
        Me.txt_preco_unitario.BackColor = System.Drawing.Color.BurlyWood
        Me.txt_preco_unitario.Location = New System.Drawing.Point(482, 62)
        Me.txt_preco_unitario.Name = "txt_preco_unitario"
        Me.txt_preco_unitario.ReadOnly = True
        Me.txt_preco_unitario.Size = New System.Drawing.Size(244, 20)
        Me.txt_preco_unitario.TabIndex = 50
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(479, 45)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(113, 13)
        Me.Label4.TabIndex = 49
        Me.Label4.Text = "PREÇO UNITÁRIO"
        '
        'txt_subtotal
        '
        Me.txt_subtotal.BackColor = System.Drawing.Color.BurlyWood
        Me.txt_subtotal.Location = New System.Drawing.Point(482, 163)
        Me.txt_subtotal.Name = "txt_subtotal"
        Me.txt_subtotal.ReadOnly = True
        Me.txt_subtotal.Size = New System.Drawing.Size(244, 20)
        Me.txt_subtotal.TabIndex = 54
        Me.txt_subtotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(479, 147)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(72, 13)
        Me.Label5.TabIndex = 53
        Me.Label5.Text = "SUBTOTAL"
        '
        'dgv_itens_venda
        '
        Me.dgv_itens_venda.AllowUserToAddRows = False
        Me.dgv_itens_venda.AllowUserToDeleteRows = False
        Me.dgv_itens_venda.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgv_itens_venda.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgv_itens_venda.BackgroundColor = System.Drawing.Color.Bisque
        Me.dgv_itens_venda.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_itens_venda.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.col_isbn, Me.col_livro, Me.col_estoque, Me.col_preco_unitario, Me.col_quantidade, Me.col_subtotal, Me.col_excluir})
        Me.dgv_itens_venda.Location = New System.Drawing.Point(0, 189)
        Me.dgv_itens_venda.Name = "dgv_itens_venda"
        Me.dgv_itens_venda.ReadOnly = True
        Me.dgv_itens_venda.RowHeadersWidth = 51
        Me.dgv_itens_venda.Size = New System.Drawing.Size(800, 187)
        Me.dgv_itens_venda.TabIndex = 55
        '
        'cmb_cliente
        '
        Me.cmb_cliente.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_cliente.FormattingEnabled = True
        Me.cmb_cliente.Location = New System.Drawing.Point(10, 111)
        Me.cmb_cliente.Name = "cmb_cliente"
        Me.cmb_cliente.Size = New System.Drawing.Size(102, 21)
        Me.cmb_cliente.TabIndex = 56
        '
        'cmb_livro
        '
        Me.cmb_livro.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_livro.FormattingEnabled = True
        Me.cmb_livro.Location = New System.Drawing.Point(189, 111)
        Me.cmb_livro.Name = "cmb_livro"
        Me.cmb_livro.Size = New System.Drawing.Size(244, 21)
        Me.cmb_livro.TabIndex = 57
        '
        'txt_estoque
        '
        Me.txt_estoque.BackColor = System.Drawing.Color.BurlyWood
        Me.txt_estoque.Location = New System.Drawing.Point(189, 163)
        Me.txt_estoque.Name = "txt_estoque"
        Me.txt_estoque.ReadOnly = True
        Me.txt_estoque.Size = New System.Drawing.Size(244, 20)
        Me.txt_estoque.TabIndex = 59
        Me.txt_estoque.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(186, 147)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(70, 13)
        Me.Label7.TabIndex = 58
        Me.Label7.Text = "ESTOQUE "
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.IndianRed
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.txt_total_venda)
        Me.Panel1.Controls.Add(Me.btn_salvar_venda)
        Me.Panel1.Location = New System.Drawing.Point(0, 377)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(799, 34)
        Me.Panel1.TabIndex = 60
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(459, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(47, 13)
        Me.Label9.TabIndex = 61
        Me.Label9.Text = "TOTAL"
        '
        'txt_total_venda
        '
        Me.txt_total_venda.BackColor = System.Drawing.Color.BurlyWood
        Me.txt_total_venda.Location = New System.Drawing.Point(453, 12)
        Me.txt_total_venda.Name = "txt_total_venda"
        Me.txt_total_venda.ReadOnly = True
        Me.txt_total_venda.Size = New System.Drawing.Size(244, 20)
        Me.txt_total_venda.TabIndex = 62
        Me.txt_total_venda.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btn_salvar_venda
        '
        Me.btn_salvar_venda.Location = New System.Drawing.Point(716, 11)
        Me.btn_salvar_venda.Name = "btn_salvar_venda"
        Me.btn_salvar_venda.Size = New System.Drawing.Size(72, 20)
        Me.btn_salvar_venda.TabIndex = 62
        Me.btn_salvar_venda.Text = "SALVAR"
        Me.btn_salvar_venda.UseVisualStyleBackColor = True
        '
        'col_isbn
        '
        Me.col_isbn.HeaderText = "ISBN"
        Me.col_isbn.MinimumWidth = 6
        Me.col_isbn.Name = "col_isbn"
        Me.col_isbn.ReadOnly = True
        Me.col_isbn.Width = 57
        '
        'col_livro
        '
        Me.col_livro.HeaderText = "LIVRO"
        Me.col_livro.MinimumWidth = 6
        Me.col_livro.Name = "col_livro"
        Me.col_livro.ReadOnly = True
        Me.col_livro.Width = 64
        '
        'col_estoque
        '
        Me.col_estoque.HeaderText = "ESTOQUE"
        Me.col_estoque.Name = "col_estoque"
        Me.col_estoque.ReadOnly = True
        Me.col_estoque.Width = 84
        '
        'col_preco_unitario
        '
        Me.col_preco_unitario.HeaderText = "PREÇO UNITÁRIO"
        Me.col_preco_unitario.Name = "col_preco_unitario"
        Me.col_preco_unitario.ReadOnly = True
        Me.col_preco_unitario.Width = 114
        '
        'col_quantidade
        '
        Me.col_quantidade.HeaderText = "QUANTIDADE"
        Me.col_quantidade.Name = "col_quantidade"
        Me.col_quantidade.ReadOnly = True
        Me.col_quantidade.Width = 103
        '
        'col_subtotal
        '
        Me.col_subtotal.HeaderText = "SUBTOTAL"
        Me.col_subtotal.Name = "col_subtotal"
        Me.col_subtotal.ReadOnly = True
        Me.col_subtotal.Width = 89
        '
        'col_excluir
        '
        Me.col_excluir.HeaderText = "EXCLUIR"
        Me.col_excluir.Name = "col_excluir"
        Me.col_excluir.ReadOnly = True
        Me.col_excluir.UseColumnTextForButtonValue = True
        Me.col_excluir.Width = 59
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.txt_estoque)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.cmb_livro)
        Me.Controls.Add(Me.cmb_cliente)
        Me.Controls.Add(Me.dgv_itens_venda)
        Me.Controls.Add(Me.txt_subtotal)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txt_quantidade)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txt_preco_unitario)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.dtp_data_venda)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txt_isbn)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.labelvenda)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txt_id_venda)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form3"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        CType(Me.dgv_itens_venda, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label8 As Label
    Friend WithEvents txt_isbn As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents btn_adicionar_item As ToolStripButton
    Friend WithEvents ToolStripLabel1 As ToolStripLabel
    Friend WithEvents txt_buscar_cliente As ToolStripTextBox
    Friend WithEvents ToolStripLabel2 As ToolStripLabel
    Friend WithEvents cmb_campo_cliente As ToolStripComboBox
    Friend WithEvents labelvenda As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txt_id_venda As MaskedTextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents dtp_data_venda As DateTimePicker
    Friend WithEvents txt_quantidade As MaskedTextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txt_preco_unitario As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txt_subtotal As MaskedTextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents dgv_itens_venda As DataGridView
    Friend WithEvents cmb_cliente As ComboBox
    Friend WithEvents cmb_livro As ComboBox
    Friend WithEvents txt_estoque As MaskedTextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label9 As Label
    Friend WithEvents txt_total_venda As MaskedTextBox
    Friend WithEvents btn_salvar_venda As Button
    Friend WithEvents col_isbn As DataGridViewTextBoxColumn
    Friend WithEvents col_livro As DataGridViewTextBoxColumn
    Friend WithEvents col_estoque As DataGridViewTextBoxColumn
    Friend WithEvents col_preco_unitario As DataGridViewTextBoxColumn
    Friend WithEvents col_quantidade As DataGridViewTextBoxColumn
    Friend WithEvents col_subtotal As DataGridViewTextBoxColumn
    Friend WithEvents col_excluir As DataGridViewButtonColumn
End Class
