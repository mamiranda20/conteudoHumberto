﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.isbn = New System.Windows.Forms.MaskedTextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.titulo = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.img_foto = New System.Windows.Forms.PictureBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.quantidade = New System.Windows.Forms.MaskedTextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.dgv_dados = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AUTORES = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MARCAFABRICANTE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FONE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PRECOVENDA = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MARGEMLUCRO = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.btn_editar = New System.Windows.Forms.DataGridViewImageColumn()
        Me.btn_excluir = New System.Windows.Forms.DataGridViewImageColumn()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.btn_gravar = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.txt_buscar = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripLabel2 = New System.Windows.Forms.ToolStripLabel()
        Me.cmb_campo = New System.Windows.Forms.ToolStripComboBox()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.editora = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.preco_venda = New System.Windows.Forms.MaskedTextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.preco_custo = New System.Windows.Forms.MaskedTextBox()
        Me.autor = New System.Windows.Forms.TextBox()
        Me.categoria = New System.Windows.Forms.ComboBox()
        CType(Me.img_foto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv_dados, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(19, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(36, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ISBN"
        '
        'isbn
        '
        Me.isbn.BackColor = System.Drawing.Color.BurlyWood
        Me.isbn.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.isbn.Location = New System.Drawing.Point(22, 53)
        Me.isbn.Name = "isbn"
        Me.isbn.Size = New System.Drawing.Size(100, 13)
        Me.isbn.TabIndex = 1
        Me.isbn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(19, 85)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(115, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "TITULO DO LIVRO"
        '
        'titulo
        '
        Me.titulo.AccessibleRole = System.Windows.Forms.AccessibleRole.Window
        Me.titulo.BackColor = System.Drawing.Color.BurlyWood
        Me.titulo.Location = New System.Drawing.Point(22, 102)
        Me.titulo.Name = "titulo"
        Me.titulo.Size = New System.Drawing.Size(301, 20)
        Me.titulo.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(19, 135)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(50, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "AUTOR"
        '
        'img_foto
        '
        Me.img_foto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.img_foto.Image = CType(resources.GetObject("img_foto.Image"), System.Drawing.Image)
        Me.img_foto.Location = New System.Drawing.Point(678, 39)
        Me.img_foto.Name = "img_foto"
        Me.img_foto.Size = New System.Drawing.Size(160, 155)
        Me.img_foto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.img_foto.TabIndex = 6
        Me.img_foto.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(19, 181)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(111, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "QTD DISPONÍVEL"
        '
        'quantidade
        '
        Me.quantidade.BackColor = System.Drawing.Color.BurlyWood
        Me.quantidade.Location = New System.Drawing.Point(22, 197)
        Me.quantidade.Name = "quantidade"
        Me.quantidade.Size = New System.Drawing.Size(132, 20)
        Me.quantidade.TabIndex = 8
        Me.quantidade.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(343, 39)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(78, 13)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "CATEGORIA"
        '
        'dgv_dados
        '
        Me.dgv_dados.AllowUserToAddRows = False
        Me.dgv_dados.AllowUserToDeleteRows = False
        Me.dgv_dados.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgv_dados.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgv_dados.BackgroundColor = System.Drawing.Color.Bisque
        Me.dgv_dados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_dados.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column7, Me.AUTORES, Me.MARCAFABRICANTE, Me.Column3, Me.FONE, Me.PRECOVENDA, Me.MARGEMLUCRO, Me.btn_editar, Me.btn_excluir})
        Me.dgv_dados.Location = New System.Drawing.Point(22, 279)
        Me.dgv_dados.Name = "dgv_dados"
        Me.dgv_dados.ReadOnly = True
        Me.dgv_dados.RowHeadersWidth = 51
        Me.dgv_dados.Size = New System.Drawing.Size(906, 208)
        Me.dgv_dados.TabIndex = 11
        '
        'Column1
        '
        Me.Column1.HeaderText = "ISBN"
        Me.Column1.MinimumWidth = 6
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Width = 57
        '
        'Column7
        '
        Me.Column7.HeaderText = "TITULO"
        Me.Column7.MinimumWidth = 6
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        Me.Column7.Width = 71
        '
        'AUTORES
        '
        Me.AUTORES.HeaderText = "AUTOR"
        Me.AUTORES.Name = "AUTORES"
        Me.AUTORES.ReadOnly = True
        Me.AUTORES.Width = 70
        '
        'MARCAFABRICANTE
        '
        Me.MARCAFABRICANTE.HeaderText = "EDITORA"
        Me.MARCAFABRICANTE.Name = "MARCAFABRICANTE"
        Me.MARCAFABRICANTE.ReadOnly = True
        Me.MARCAFABRICANTE.Width = 80
        '
        'Column3
        '
        Me.Column3.HeaderText = "CATEGORIA"
        Me.Column3.MinimumWidth = 6
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Width = 94
        '
        'FONE
        '
        Me.FONE.HeaderText = "QTD DISPONIVEL"
        Me.FONE.MinimumWidth = 6
        Me.FONE.Name = "FONE"
        Me.FONE.ReadOnly = True
        Me.FONE.Width = 112
        '
        'PRECOVENDA
        '
        Me.PRECOVENDA.HeaderText = "PREÇO VENDA"
        Me.PRECOVENDA.Name = "PRECOVENDA"
        Me.PRECOVENDA.ReadOnly = True
        '
        'MARGEMLUCRO
        '
        Me.MARGEMLUCRO.HeaderText = "MARGEM LUCRO"
        Me.MARGEMLUCRO.Name = "MARGEMLUCRO"
        Me.MARGEMLUCRO.ReadOnly = True
        Me.MARGEMLUCRO.Width = 110
        '
        'btn_editar
        '
        Me.btn_editar.HeaderText = "EDITAR"
        Me.btn_editar.Image = CType(resources.GetObject("btn_editar.Image"), System.Drawing.Image)
        Me.btn_editar.MinimumWidth = 6
        Me.btn_editar.Name = "btn_editar"
        Me.btn_editar.ReadOnly = True
        Me.btn_editar.Width = 53
        '
        'btn_excluir
        '
        Me.btn_excluir.HeaderText = "EXCLUIR"
        Me.btn_excluir.Image = CType(resources.GetObject("btn_excluir.Image"), System.Drawing.Image)
        Me.btn_excluir.MinimumWidth = 6
        Me.btn_excluir.Name = "btn_excluir"
        Me.btn_excluir.ReadOnly = True
        Me.btn_excluir.Width = 59
        '
        'ToolStrip1
        '
        Me.ToolStrip1.BackColor = System.Drawing.Color.RosyBrown
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btn_gravar, Me.ToolStripLabel1, Me.txt_buscar, Me.ToolStripLabel2, Me.cmb_campo})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(941, 27)
        Me.ToolStrip1.TabIndex = 12
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'btn_gravar
        '
        Me.btn_gravar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btn_gravar.Image = CType(resources.GetObject("btn_gravar.Image"), System.Drawing.Image)
        Me.btn_gravar.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btn_gravar.Name = "btn_gravar"
        Me.btn_gravar.Size = New System.Drawing.Size(24, 24)
        Me.btn_gravar.Text = "ToolStripButton1"
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(194, 24)
        Me.ToolStripLabel1.Text = "Digite um parâmetro de pesquisa:"
        '
        'txt_buscar
        '
        Me.txt_buscar.BackColor = System.Drawing.Color.BurlyWood
        Me.txt_buscar.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt_buscar.Name = "txt_buscar"
        Me.txt_buscar.Size = New System.Drawing.Size(100, 27)
        '
        'ToolStripLabel2
        '
        Me.ToolStripLabel2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripLabel2.Name = "ToolStripLabel2"
        Me.ToolStripLabel2.Size = New System.Drawing.Size(111, 24)
        Me.ToolStripLabel2.Text = "Selecione o campo"
        '
        'cmb_campo
        '
        Me.cmb_campo.BackColor = System.Drawing.Color.BurlyWood
        Me.cmb_campo.Name = "cmb_campo"
        Me.cmb_campo.Size = New System.Drawing.Size(121, 27)
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'editora
        '
        Me.editora.BackColor = System.Drawing.Color.BurlyWood
        Me.editora.Location = New System.Drawing.Point(346, 111)
        Me.editora.Name = "editora"
        Me.editora.Size = New System.Drawing.Size(244, 20)
        Me.editora.TabIndex = 14
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(343, 94)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(62, 13)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "EDITORA"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(188, 181)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(95, 13)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "PREÇO CUSTO"
        '
        'preco_venda
        '
        Me.preco_venda.BackColor = System.Drawing.Color.BurlyWood
        Me.preco_venda.Location = New System.Drawing.Point(346, 197)
        Me.preco_venda.Name = "preco_venda"
        Me.preco_venda.Size = New System.Drawing.Size(132, 20)
        Me.preco_venda.TabIndex = 18
        Me.preco_venda.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(343, 181)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(95, 13)
        Me.Label8.TabIndex = 17
        Me.Label8.Text = "PREÇO VENDA"
        '
        'preco_custo
        '
        Me.preco_custo.BackColor = System.Drawing.Color.BurlyWood
        Me.preco_custo.Cursor = System.Windows.Forms.Cursors.PanSouth
        Me.preco_custo.Location = New System.Drawing.Point(191, 197)
        Me.preco_custo.Name = "preco_custo"
        Me.preco_custo.Size = New System.Drawing.Size(132, 20)
        Me.preco_custo.TabIndex = 16
        Me.preco_custo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'autor
        '
        Me.autor.AccessibleRole = System.Windows.Forms.AccessibleRole.Window
        Me.autor.BackColor = System.Drawing.Color.BurlyWood
        Me.autor.Location = New System.Drawing.Point(22, 151)
        Me.autor.Name = "autor"
        Me.autor.Size = New System.Drawing.Size(301, 20)
        Me.autor.TabIndex = 19
        '
        'categoria
        '
        Me.categoria.BackColor = System.Drawing.Color.BurlyWood
        Me.categoria.FormattingEnabled = True
        Me.categoria.Location = New System.Drawing.Point(349, 58)
        Me.categoria.Name = "categoria"
        Me.categoria.Size = New System.Drawing.Size(240, 21)
        Me.categoria.TabIndex = 20
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.PapayaWhip
        Me.ClientSize = New System.Drawing.Size(941, 499)
        Me.Controls.Add(Me.categoria)
        Me.Controls.Add(Me.autor)
        Me.Controls.Add(Me.preco_venda)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.preco_custo)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.editora)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.dgv_dados)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.quantidade)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.img_foto)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.titulo)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.isbn)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "CADASTRO DE CLIENTES"
        CType(Me.img_foto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv_dados, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents isbn As MaskedTextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents titulo As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents img_foto As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents quantidade As MaskedTextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents dgv_dados As DataGridView
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents btn_gravar As ToolStripButton
    Friend WithEvents ToolStripLabel1 As ToolStripLabel
    Friend WithEvents txt_buscar As ToolStripTextBox
    Friend WithEvents ToolStripLabel2 As ToolStripLabel
    Friend WithEvents cmb_campo As ToolStripComboBox
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents editora As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents preco_venda As MaskedTextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents preco_custo As MaskedTextBox
    Friend WithEvents autor As TextBox
    Friend WithEvents categoria As ComboBox
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column7 As DataGridViewTextBoxColumn
    Friend WithEvents AUTORES As DataGridViewTextBoxColumn
    Friend WithEvents MARCAFABRICANTE As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents FONE As DataGridViewTextBoxColumn
    Friend WithEvents PRECOVENDA As DataGridViewTextBoxColumn
    Friend WithEvents MARGEMLUCRO As DataGridViewTextBoxColumn
    Friend WithEvents btn_editar As DataGridViewImageColumn
    Friend WithEvents btn_excluir As DataGridViewImageColumn
End Class
