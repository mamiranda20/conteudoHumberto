﻿Imports System.Data.SqlClient
Imports System.IO
Public Class Form2

    ' CONEXÃO COM O BANCO 
    Dim conexao As New SqlConnection("Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=cad_livraria;Integrated Security=True")

    ' Guarda o caminho da foto selecionada
    Dim caminhoFoto As String = ""

    ' Controla se estamos editando um registro existente
    Dim modoEdicao As Boolean = False

    ' QUANDO O FORM ABRIR 
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            carregarComboBusca()
            carregarClientes()
            limparCampos()

            txt_id_cliente.ReadOnly = True
            txt_id_cliente.Enabled = False
        Catch ex As Exception
            MessageBox.Show("Erro ao abrir a tela: " & ex.Message)
        End Try
    End Sub

    ' ===== PREENCHE O COMBO DE BUSCA =====
    Private Sub carregarComboBusca()
        cmb_campo_cliente.Items.Clear()
        cmb_campo_cliente.Items.Add("nome")
        cmb_campo_cliente.Items.Add("cpf")
        cmb_campo_cliente.Items.Add("telefone")
        cmb_campo_cliente.Items.Add("email")
        cmb_campo_cliente.SelectedIndex = 0
    End Sub

    ' ===== CARREGA OS DADOS NO GRID =====
    Private Sub carregarClientes()
        Try
            Dim sql As String = "SELECT id_cliente, nome, cpf, telefone, email, foto FROM dbo.tb_clientes ORDER BY id_cliente"

            Dim da As New SqlDataAdapter(sql, conexao)
            Dim dt As New DataTable()
            da.Fill(dt)

            dgv_dados_clientes.AutoGenerateColumns = False
            dgv_dados_clientes.DataSource = dt

        Catch ex As Exception
            MessageBox.Show("Erro ao carregar clientes: " & ex.Message)
        End Try
    End Sub

    ' ===== LIMPA OS CAMPOS =====
    Private Sub limparCampos()
        txt_id_cliente.Text = ""
        txt_nome.Text = ""
        txt_cpf.Text = ""
        txt_telefone.Text = ""
        txt_email.Text = ""
        txt_buscar_cliente.Text = ""

        caminhoFoto = ""
        img_foto_clientes.Image = Nothing
        img_foto_clientes.Tag = ""

        modoEdicao = False
        txt_nome.Focus()
    End Sub

    ' ===== VALIDAÇÃO SIMPLES =====
    Private Function validarCampos() As Boolean
        If txt_nome.Text.Trim() = "" Then
            MessageBox.Show("Digite o nome.")
            txt_nome.Focus()
            Return False
        End If

        If txt_cpf.Text.Trim() = "" Then
            MessageBox.Show("Digite o CPF.")
            txt_cpf.Focus()
            Return False
        End If

        Return True
    End Function

    ' ===== BOTÃO SALVAR =====
    Private Sub btn_salvar_Click(sender As Object, e As EventArgs) Handles btn_gravar_clientes.Click
        If validarCampos() = False Then Exit Sub

        Try
            If modoEdicao = False Then
                inserirCliente()
            Else
                atualizarCliente()
            End If

            carregarClientes()
            limparCampos()

        Catch ex As Exception
            MessageBox.Show("Erro ao salvar: " & ex.Message)
        End Try
    End Sub

    ' ===== INSERIR NOVO CLIENTE =====
    Private Sub inserirCliente()
        Dim sql As String = "INSERT INTO dbo.tb_clientes (nome, cpf, telefone, email, foto) " &
                            "VALUES (@nome, @cpf, @telefone, @email, @foto)"

        Dim cmd As New SqlCommand(sql, conexao)
        cmd.Parameters.AddWithValue("@nome", txt_nome.Text.Trim())
        cmd.Parameters.AddWithValue("@cpf", txt_cpf.Text.Trim())
        cmd.Parameters.AddWithValue("@telefone", txt_telefone.Text.Trim())
        cmd.Parameters.AddWithValue("@email", txt_email.Text.Trim())
        cmd.Parameters.AddWithValue("@foto", caminhoFoto)

        conexao.Open()
        cmd.ExecuteNonQuery()
        conexao.Close()

        MessageBox.Show("Cliente salvo com sucesso!")
    End Sub

    ' ===== ATUALIZAR CLIENTE =====
    Private Sub atualizarCliente()
        Dim sql As String = "UPDATE dbo.tb_clientes SET nome=@nome, cpf=@cpf, telefone=@telefone, email=@email, foto=@foto " &
                            "WHERE id_cliente=@id_cliente"

        Dim cmd As New SqlCommand(sql, conexao)
        cmd.Parameters.AddWithValue("@id_cliente", Convert.ToInt32(txt_id_cliente.Text))
        cmd.Parameters.AddWithValue("@nome", txt_nome.Text.Trim())
        cmd.Parameters.AddWithValue("@cpf", txt_cpf.Text.Trim())
        cmd.Parameters.AddWithValue("@telefone", txt_telefone.Text.Trim())
        cmd.Parameters.AddWithValue("@email", txt_email.Text.Trim())
        cmd.Parameters.AddWithValue("@foto", caminhoFoto)

        conexao.Open()
        cmd.ExecuteNonQuery()
        conexao.Close()

        MessageBox.Show("Cliente atualizado com sucesso!")
    End Sub

    ' ===== EXCLUIR CLIENTE =====
    Private Sub excluirCliente(id As Integer)
        Try
            Dim resposta As DialogResult
            resposta = MessageBox.Show("Deseja realmente excluir este cliente?", "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            If resposta = DialogResult.No Then Exit Sub

            Dim sql As String = "DELETE FROM dbo.tb_clientes WHERE id_cliente=@id_cliente"

            Dim cmd As New SqlCommand(sql, conexao)
            cmd.Parameters.AddWithValue("@id_cliente", id)

            conexao.Open()
            cmd.ExecuteNonQuery()
            conexao.Close()

            MessageBox.Show("Cliente excluído com sucesso!")

            carregarClientes()
            limparCampos()

        Catch ex As Exception
            MessageBox.Show("Erro ao excluir: " & ex.Message)
            If conexao.State = ConnectionState.Open Then
                conexao.Close()
            End If
        End Try
    End Sub

    ' ===== CLICAR NA FOTO PARA ESCOLHER IMAGEM =====
    Private Sub pic_foto_Click(sender As Object, e As EventArgs) Handles img_foto_clientes.Click
        Try
            Dim abrir As New OpenFileDialog()

            abrir.Title = "Selecionar foto"
            abrir.Filter = "Arquivos de Imagem|*.jpg;*.jpeg;*.png;*.bmp"

            If abrir.ShowDialog() = DialogResult.OK Then
                caminhoFoto = abrir.FileName
                img_foto_clientes.Image = Image.FromFile(caminhoFoto)
                img_foto_clientes.SizeMode = PictureBoxSizeMode.StretchImage
                img_foto_clientes.Tag = caminhoFoto
            End If

        Catch ex As Exception
            MessageBox.Show("Erro ao carregar foto: " & ex.Message)
        End Try
    End Sub

    ' ===== CLIQUE NAS CÉLULAS DO GRID =====
    Private Sub dgv_clientes_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_dados_clientes.CellContentClick
        Try
            If e.RowIndex < 0 Then Exit Sub

            Dim id As Integer = Convert.ToInt32(dgv_dados_clientes.Rows(e.RowIndex).Cells("col_id_cliente").Value)

            ' BOTÃO EDITAR
            If dgv_dados_clientes.Columns(e.ColumnIndex).Name = "col_editar" Then
                txt_id_cliente.Text = dgv_dados_clientes.Rows(e.RowIndex).Cells("col_id_cliente").Value.ToString()
                txt_nome.Text = dgv_dados_clientes.Rows(e.RowIndex).Cells("col_nome").Value.ToString()
                txt_cpf.Text = dgv_dados_clientes.Rows(e.RowIndex).Cells("col_cpf").Value.ToString()
                txt_telefone.Text = dgv_dados_clientes.Rows(e.RowIndex).Cells("col_telefone").Value.ToString()
                txt_email.Text = dgv_dados_clientes.Rows(e.RowIndex).Cells("col_email").Value.ToString()

                ' Carrega a foto do banco
                buscarFotoCliente(id)

                modoEdicao = True
            End If

            ' BOTÃO EXCLUIR
            If dgv_dados_clientes.Columns(e.ColumnIndex).Name = "col_excluir" Then
                excluirCliente(id)
            End If

        Catch ex As Exception
            MessageBox.Show("Erro ao clicar no grid: " & ex.Message)
        End Try
    End Sub

    ' ===== BUSCA A FOTO DO CLIENTE PELO ID =====
    Private Sub buscarFotoCliente(id As Integer)
        Try
            Dim sql As String = "SELECT foto FROM dbo.tb_clientes WHERE id_cliente=@id_cliente"
            Dim cmd As New SqlCommand(sql, conexao)
            cmd.Parameters.AddWithValue("@id_cliente", id)

            conexao.Open()
            Dim resultado = cmd.ExecuteScalar()
            conexao.Close()

            If resultado IsNot Nothing AndAlso Not IsDBNull(resultado) Then
                caminhoFoto = resultado.ToString()

                If caminhoFoto <> "" AndAlso File.Exists(caminhoFoto) Then
                    img_foto_clientes.Image = Image.FromFile(caminhoFoto)
                    img_foto_clientes.SizeMode = PictureBoxSizeMode.StretchImage
                    img_foto_clientes.Tag = caminhoFoto
                Else
                    img_foto_clientes.Image = Nothing
                    img_foto_clientes.Tag = ""
                End If
            Else
                caminhoFoto = ""
                img_foto_clientes.Image = Nothing
                img_foto_clientes.Tag = ""
            End If

        Catch ex As Exception
            If conexao.State = ConnectionState.Open Then
                conexao.Close()
            End If
            MessageBox.Show("Erro ao buscar foto: " & ex.Message)
        End Try
    End Sub

    ' ===== BUSCA DINÂMICA =====
    Private Sub txt_busca_TextChanged(sender As Object, e As EventArgs) Handles txt_buscar_cliente.TextChanged
        Try
            If cmb_campo_cliente.SelectedItem Is Nothing Then Exit Sub

            Dim campo As String = cmb_campo_cliente.SelectedItem.ToString()
            Dim sql As String = "SELECT id_cliente, nome, cpf, telefone, email, foto " &
                                "FROM dbo.tb_clientes " &
                                "WHERE " & campo & " LIKE @valor " &
                                "ORDER BY id_cliente"

            Dim cmd As New SqlCommand(sql, conexao)
            cmd.Parameters.AddWithValue("@valor", "%" & txt_buscar_cliente.Text.Trim() & "%")

            Dim da As New SqlDataAdapter(cmd)
            Dim dt As New DataTable()
            da.Fill(dt)

            dgv_dados_clientes.DataSource = dt

        Catch ex As Exception
            MessageBox.Show("Erro ao buscar: " & ex.Message)
        End Try
    End Sub


    ' ===== QUANDO TROCAR O CAMPO DO COMBO, REFAR A BUSCA =====
    Private Sub cmb_campo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmb_campo_cliente.SelectedIndexChanged
        txt_busca_TextChanged(Nothing, Nothing)
    End Sub

End Class
