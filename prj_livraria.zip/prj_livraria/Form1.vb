﻿Imports System.Data.SqlClient
Public Class Form1

    'EDITAR E SALVAR
    Dim modoEdicao As Boolean = False

    ' CAMINHO DA IMAGEM
    Dim diretorio As String = ""

    ' CONEXÃO COM O BANCO DE DADOS SQL SERVER
    Dim conexao As New SqlConnection("Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=cad_livraria;Integrated Security=True")

    ' CARREGAR DADOS AO INICIAR O FORMULÁRIO
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Carregar_dados()

        cmb_campo.Items.Clear()
        cmb_campo.Items.Add("titulo")
        cmb_campo.Items.Add("autor")
        cmb_campo.Items.Add("categoria")
        cmb_campo.Items.Add("editora")

        cmb_campo.SelectedIndex = 0

        ' CATEGORIAS DE LIVROS
        categoria.Items.Clear()
        categoria.Items.Add("Romance")
        categoria.Items.Add("Ficção")
        categoria.Items.Add("Terror")
        categoria.Items.Add("Fantasia")
        categoria.Items.Add("Autoajuda")
        categoria.Items.Add("Educação")
        categoria.Items.Add("Tecnologia")
        categoria.Items.Add("História")
        categoria.Items.Add("Infantil")

        categoria.SelectedIndex = 0 ' Seleciona a primeira categoria por padrão
    End Sub

    ' SELECIONAR FOTO DO PRODUTO
    Private Sub Img_foto_Click(sender As Object, e As EventArgs) Handles img_foto.Click
        Try
            With OpenFileDialog1
                .Title = "Selecione uma Foto"
                .InitialDirectory = Application.StartupPath & "\Fotos"

                If .ShowDialog() = DialogResult.OK Then
                    diretorio = .FileName
                    img_foto.Load(diretorio)
                End If
            End With
        Catch ex As Exception
            MsgBox("Erro ao carregar a foto")
        End Try
    End Sub

    ' GRAVAR LIVRO
    Private Sub btn_gravar_Click(sender As Object, e As EventArgs) Handles btn_gravar.Click
        Try
            'VALIDAÇÃO DE FOTO
            If diretorio = "" Then
                MsgBox("Por favor, selecione uma foto!")
                Exit Sub
            End If

            If conexao.State = ConnectionState.Closed Then
                conexao.Open()
            End If

            Dim cmd As SqlCommand

            If modoEdicao = False Then
                ' NOVO LIVRO
                cmd = New SqlCommand(
                    "INSERT INTO tb_livros
                    (isbn, titulo, autor, categoria, editora, quantidade, preco_custo, preco_venda, foto) 
                    VALUES 
                    (@isbn, @titulo, @autor, @categoria, @editora, @quantidade, @preco_custo, @preco_venda, @foto)", conexao)
            Else
                ' ATUALIZAR LIVRO EXISTENTE
                cmd = New SqlCommand(
                    "UPDATE tb_livros SET 
                    titulo = @titulo, 
                    autor = @autor, 
                    categoria = @categoria, 
                    editora = @editora, 
                    quantidade = @quantidade, 
                    preco_custo = @preco_custo, 
                    preco_venda = @preco_venda, 
                    foto = @foto 
                    WHERE isbn = @isbn", conexao)

            End If

            cmd.Parameters.AddWithValue("@isbn", isbn.Text)
            cmd.Parameters.AddWithValue("@titulo", titulo.Text)
            cmd.Parameters.AddWithValue("@autor", autor.Text)
            cmd.Parameters.AddWithValue("@categoria", categoria.Text)
            cmd.Parameters.AddWithValue("@editora", editora.Text)
            cmd.Parameters.AddWithValue("@quantidade", Convert.ToInt32(quantidade.Text))
            cmd.Parameters.AddWithValue("@preco_custo", Convert.ToDecimal(preco_custo.Text))
            cmd.Parameters.AddWithValue("@preco_venda", Convert.ToDecimal(preco_venda.Text))
            cmd.Parameters.AddWithValue("@foto", diretorio)

            cmd.ExecuteNonQuery()

            If modoEdicao Then
                MsgBox("Livro atualizado com sucesso!")
            Else
                MsgBox("Livro cadastrado com sucesso!")
            End If

            modoEdicao = False

            Limpar_cadastro()
            Carregar_dados()

        Catch ex As Exception
            MsgBox("Erro ao gravar: " & ex.Message)
        End Try
    End Sub

    ' CARREGAR DADOS NO GRID
    Sub Carregar_dados()
        Try
            If conexao.State = ConnectionState.Closed Then
                conexao.Open()
            End If

            Dim sql As String = "SELECT * FROM tb_livros ORDER BY titulo"
            Dim cmd As New SqlCommand(sql, conexao)
            Dim dr As SqlDataReader = cmd.ExecuteReader()

            dgv_dados.Rows.Clear()

            While dr.Read()
                Dim lucro As Double = dr("preco_venda") - dr("preco_custo")

                dgv_dados.Rows.Add(
                    dr("isbn"),
                    dr("titulo"),
                    dr("autor"),
                    dr("categoria"),
                    dr("editora"),
                    dr("quantidade"),
                    dr("preco_venda"),
                    lucro
                )
            End While

            dr.Close()

        Catch ex As Exception
            MsgBox("Erro ao carregar os dados: " & ex.Message)
        End Try
    End Sub

    ' LIMPAR CAMPOS 
    Sub Limpar_cadastro()
        isbn.Clear()
        titulo.Clear()
        autor.Clear()
        categoria.Text = ""
        editora.Clear()
        quantidade.Clear()
        preco_custo.Clear()
        preco_venda.Clear()
        img_foto.Image = Nothing
        diretorio = ""
        titulo.Focus()
    End Sub

    Private Sub dgv_dados_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_dados.CellContentClick

        If e.RowIndex < 0 Then Exit Sub ' Ignorar cliques no cabeçalho

        Dim isbnSelecionado As String = dgv_dados.Rows(e.RowIndex).Cells(0).Value

        'EXCLUIR
        If dgv_dados.Columns(e.ColumnIndex).Name = "btn_excluir" Then

            Dim resp = MsgBox("Deseja realmente excluir este livro?", MsgBoxStyle.YesNo)

            If resp = MsgBoxResult.Yes Then
                If conexao.State = ConnectionState.Closed Then conexao.Open()

                Dim cmd As New SqlCommand("DELETE FROM tb_livros WHERE isbn = @isbn", conexao)
                cmd.Parameters.AddWithValue("@isbn", isbnSelecionado)
                cmd.ExecuteNonQuery()

                MsgBox("Livro excluído")

                Carregar_dados()
            End If
        End If

        'BOTAO EDITAR
        If dgv_dados.Columns(e.ColumnIndex).Name = "btn_editar" Then

            If conexao.State = ConnectionState.Closed Then conexao.Open()

            Dim cmd As New SqlCommand("SELECT * FROM tb_livros WHERE isbn = @isbn", conexao)
            cmd.Parameters.AddWithValue("@isbn", isbnSelecionado)

            Dim dr As SqlDataReader = cmd.ExecuteReader()

            If dr.Read() Then
                isbn.Text = dr("isbn")
                titulo.Text = dr("titulo")
                autor.Text = dr("autor")
                categoria.Text = dr("categoria")
                editora.Text = dr("editora")
                quantidade.Text = dr("quantidade")
                preco_custo.Text = dr("preco_custo")
                preco_venda.Text = dr("preco_venda")
                diretorio = dr("foto")
                img_foto.Load(diretorio)

                modoEdicao = True
            End If

            dr.Close()

        End If
    End Sub

    Private Sub txt_buscar_Click(sender As Object, e As EventArgs) Handles txt_buscar.TextChanged
        Try
            If conexao.State = ConnectionState.Closed Then
                conexao.Open()
            End If


            Dim sql As String = "SELECT * FROM tb_livros WHERE " & cmb_campo.Text & " LIKE @valor ORDER BY titulo"

            Dim cmd As New SqlCommand(sql, conexao)

            cmd.Parameters.AddWithValue("@valor", txt_buscar.Text & "%")

            Dim dr As SqlDataReader = cmd.ExecuteReader()

            dgv_dados.Rows.Clear()

            While dr.Read()
                Dim lucro As Double = dr("preco_venda") - dr("preco_custo")
                dgv_dados.Rows.Add(
                    dr("isbn"),
                    dr("titulo"),
                    dr("autor"),
                    dr("categoria"),
                    dr("editora"),
                    dr("quantidade"),
                    dr("preco_venda"),
                    lucro
                )
            End While

            dr.Close()

        Catch ex As Exception
            MsgBox("Erro ao buscar: " & ex.Message)

        End Try
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub
End Class
